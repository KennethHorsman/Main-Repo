numberBig = 100

numberMedium = 10

numberSmall = 1

wordBig = "Constitution"

wordMedium = "Dance"

wordSmall = "Toy"

if wordMedium > wordSmall:
    print("True")
else:
    print("False")

if wordSmall > wordMedium:
    print("True")
else:
    print("False")